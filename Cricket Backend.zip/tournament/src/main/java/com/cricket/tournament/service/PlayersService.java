package com.cricket.tournament.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cricket.tournament.entity.Login;
import com.cricket.tournament.entity.LoginMessage;
import com.cricket.tournament.entity.Players;

import jakarta.mail.MessagingException;

public interface PlayersService {
	void savePlayers(int teamId,Players players,List<Players> playersdata);
	List<Players> getAllPlayers();
	Players updatePlayer(int playerId,Players players);
	void deletePlayer(int playerId);
	List<Players> getPlayersByTeamName(String teamName);
	Players getPlayerById(int playerId);
	void savePlayersData(Players players,List<Players> playersinfo);
	void assign(String tname,String pname,List<Players> playersdata) throws MessagingException;
	List<Players> getAllUnsoldPlayers(List<Players> playersinfo);
	void deletePlayerFromAdmin(int playerId);

	


}
