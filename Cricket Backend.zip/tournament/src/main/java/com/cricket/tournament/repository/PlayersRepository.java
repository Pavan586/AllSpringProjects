package com.cricket.tournament.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.cricket.tournament.entity.Players;
@EnableJpaRepositories
@Repository
public interface PlayersRepository extends JpaRepository<Players,Integer> {
	@Query("select p from Players p where p.teams.tname=?1")
	public List<Players> findPlayersByTeamName(String tname);
	@Query("select count(p.pid) from Players p where p.teams.id=?1")
	public int getPlayersCount(int id);
	@Query("select sum(p.pbudget) from Players p where p.teams.id=?1")
	public Integer getPlayersBudget(int id);

}
