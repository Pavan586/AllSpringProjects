package com.cricket.tournament.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cricket.tournament.entity.Players;
import com.cricket.tournament.exception.TeamBudgetExceedsException;
import com.cricket.tournament.serviceimpl.PlayersServiceImpl;

import jakarta.mail.MessagingException;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/players")
public class PlayersController {
	@Autowired
	PlayersServiceImpl cdsimpl;
	@PostMapping("/addplayers/{teamId}")
	public void savePlayers(@PathVariable int teamId,@RequestBody Players players) {
		List<Players> playersdata=getPlayers();
		cdsimpl.savePlayers(teamId,players,playersdata);
	}
	@GetMapping("/getallplayers")
	public List<Players> getPlayers() {
		return cdsimpl.getAllPlayers();
		
	}
	@PutMapping("/updateplayer/{playerId}")
	public Players updatePlayer(@PathVariable int playerId,@RequestBody Players players) {
		return cdsimpl.updatePlayer(playerId,players);
	}
	@DeleteMapping("/deleteplayer/{playerId}")
	public void deletePlayer(@PathVariable int playerId) {
		cdsimpl.deletePlayer(playerId);
		
	}
	@DeleteMapping("/deleteplayerfromadmin/{playerId}")
	public void deletePlayerFromAdmin(@PathVariable int playerId) {
		cdsimpl.deletePlayerFromAdmin(playerId);
		
	}
	@GetMapping("/getplayersbyteamname/{teamName}")
	public List<Players> getPlayersByTeamName(@PathVariable String teamName) {
		return cdsimpl.getPlayersByTeamName(teamName);
	}
	@GetMapping("/getplayerbyid/{playerId}")
	public Players getPlayerById(@PathVariable int playerId) {
		return cdsimpl.getPlayerById(playerId);
	}
	@PostMapping("/saveplayers")
	public void savePlayersData(@RequestBody Players players) {
		List<Players> playersinfo=getPlayers();
		cdsimpl.savePlayersData(players,playersinfo);
	}
	@PutMapping("/assign/{tname}/{pname}")
	public void assign(@PathVariable String tname,@PathVariable String pname) throws MessagingException {
		//Players players=new Players();
		List<Players> playersdata=getPlayers();
		cdsimpl.assign(tname,pname,playersdata);
	}
	@GetMapping("/getunsoldplayers")
	public List<Players> getAllUnsoldPlayers() {
		List<Players> playersinfo=getPlayers();
		return cdsimpl.getAllUnsoldPlayers(playersinfo);
	}
}
