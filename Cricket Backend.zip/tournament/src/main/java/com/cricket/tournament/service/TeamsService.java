package com.cricket.tournament.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cricket.tournament.entity.Players;
import com.cricket.tournament.entity.Teams;

public interface TeamsService {
	void saveTeams(Teams teams,List<Teams> teamsinfo);
	Teams getTeamById(int tid);
	List<Teams> findTeamByName(String teamName);
	String findTeamByPlayerName(String playerName,List<Players> teamsdata);
	List<Teams> getAllTeams();
	Teams updateTeam(int teamId,Teams teams);
	void deleteTeam(int teamId);
	

}
