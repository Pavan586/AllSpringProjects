package com.cricket.tournament.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cricket.tournament.entity.Players;
import com.cricket.tournament.entity.Teams;
import com.cricket.tournament.exception.IdNotFoundException;
import com.cricket.tournament.exception.PlayerNotExistsException;
import com.cricket.tournament.exception.TeamNotFoundException;
import com.cricket.tournament.serviceimpl.PlayersServiceImpl;
import com.cricket.tournament.serviceimpl.TeamsServiceImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/teams")
public class TeamsController {
	@Autowired
	TeamsServiceImpl tsimpl;
	@Autowired
	PlayersServiceImpl psimpl;
	@PostMapping("/addteams")
	public void saveTeams(@RequestBody Teams teams) {
		List<Teams> teamsinfo=getAllTeams();
		tsimpl.saveTeams(teams,teamsinfo);
		
	}
	@GetMapping("/getteambyid/{tid}")
	public Object getTeamById(@PathVariable int tid) {
		try {
		return tsimpl.getTeamById(tid);
		} 
		catch(IdNotFoundException e) {
			return e.getMessage();
			
		}
		
	}
	@GetMapping("/{tname}/getteamdatabyteamname")
	public Object findTeamsByName(@PathVariable String tname) {
		try {
		return tsimpl.findTeamByName(tname);
		}
		catch(TeamNotFoundException e) {
			return e.getMessage();
			
		}
	}
	@GetMapping("/getallteams")
	public List<Teams> getAllTeams() {
		return tsimpl.getAllTeams();
	}
	@GetMapping("/{pname}/getteamnamebyplayername")
	public String getTeamnameByPlayerName(@PathVariable String pname) {
		List<Players> playersdata=psimpl.getAllPlayers();
		try {
		return tsimpl.findTeamByPlayerName(pname,playersdata);
		}
		catch(PlayerNotExistsException p) {
			return p.getMessage();
		}
		
		
	}
	@PutMapping("/updateteam/{teamId}")
	public Teams updateTeam(@PathVariable int teamId,@RequestBody Teams teams) {
		return tsimpl.updateTeam(teamId,teams);
	}
	@DeleteMapping("/deleteteam/{teamId}")
	public void deleteTeam(@PathVariable int teamId) {
		tsimpl.deleteTeam(teamId);
		
	}
	
	

}
