package com.cricket.tournament.service;

import com.cricket.tournament.entity.AdminLogin;
import com.cricket.tournament.entity.Login;
import com.cricket.tournament.entity.LoginMessage;
import com.cricket.tournament.entity.Registration;

public interface RegistrationService {
	void saveRegisterUser(Registration registration);
	LoginMessage loginUser(Login login);
	LoginMessage loginAdmin(AdminLogin adminLogin);


}
