package com.cricket.tournament;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cricket.tournament.entity.AdminLogin;

@SpringBootApplication
public class TournamentApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(TournamentApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		AdminLogin a=new AdminLogin();
		a.setAdminEmail("admin@gmail.com");
		a.setAdminPassword("admin123");
		
	}

}
