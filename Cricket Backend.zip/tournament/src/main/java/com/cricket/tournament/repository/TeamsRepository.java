package com.cricket.tournament.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cricket.tournament.entity.Teams;

public interface TeamsRepository extends JpaRepository<Teams,Integer>{
	@Query("select t from Teams t where t.tname=?1")
	public List<Teams> findTeamByTeamName(String tname);
	/*@Query("select t.tname from Teams t where t.players.pname=?1")
	public String findTeamByPlayerName(String pname);*/
	@Query("select t.tid from Teams t where t.tname=?1")
	public int findTeamIdByTeamName(String tname);

}
