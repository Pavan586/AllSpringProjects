package com.cricket.tournament.serviceimpl;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cricket.tournament.entity.AdminLogin;
import com.cricket.tournament.entity.Login;
import com.cricket.tournament.entity.LoginMessage;
import com.cricket.tournament.entity.Registration;
import com.cricket.tournament.repository.RegistrationRepository;
import com.cricket.tournament.service.RegistrationService;

@Component
public class RegistrationServiceImpl implements RegistrationService{
	@Autowired
	RegistrationRepository regrepo;

	@Override
	public void saveRegisterUser(Registration registration) {
		// TODO Auto-generated method stub
		regrepo.save(registration);
		
	}

	@Override
	public LoginMessage loginUser(Login login) {
		// TODO Auto-generated method stub
		String msg="";
		Registration reg=regrepo.findByEmail(login.getLoginEmail());
		if(reg!=null) {
			String pass1=login.getLoginPassword();
			String pass2=reg.getUserPassword();
			Boolean isPasswordRight=pass1.equals(pass2);
			if(isPasswordRight) {
				Optional<Registration> register=Optional.of(regrepo.findByEmailAndpassword(login.getLoginEmail(), login.getLoginPassword()));
				if(register.isPresent()) {
					return new LoginMessage("Login Success",true);
				} else {
					return new LoginMessage("Login Failed",false);
				}
				
			}else {
				return new LoginMessage("Password not Match",false);
			}
		} else {
			return new LoginMessage("Email not exists",false);
		}
	}

	@Override
	public LoginMessage loginAdmin(AdminLogin adminLogin) {
		// TODO Auto-generated method stub
		if(adminLogin.getAdminEmail().equals("admin@gmail.com") && adminLogin.getAdminPassword().equals("admin123")) {
			return new LoginMessage("Login success",true);
		} else {
			return new LoginMessage("Login Failed",false);
		}
		
	}
}
