package com.cricket.tournament.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class ExceptionHandler {
	@org.springframework.web.bind.annotation.ExceptionHandler(value= {TeamNotFoundException.class})
	public ResponseEntity<Object> handleTeamNotFoundException(TeamNotFoundException team) {
		ExceptionInfo ei=new ExceptionInfo(team.getMessage(),team.getCause(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ei,HttpStatus.NOT_FOUND);
		
	}
	@org.springframework.web.bind.annotation.ExceptionHandler(value= {IdNotFoundException.class})
	public ResponseEntity<Object> handleIdNotFoundException(IdNotFoundException id) {
		ExceptionInfo ei=new ExceptionInfo(id.getMessage(),id.getCause(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ei,HttpStatus.NOT_FOUND);
		
	}
	@org.springframework.web.bind.annotation.ExceptionHandler(value= {PlayerAlreadyExistsException.class})
	public ResponseEntity<Object> handlePlayerAlreadyExistsException(PlayerAlreadyExistsException player) {
		ExceptionInfo ei=new ExceptionInfo(player.getMessage(),player.getCause(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ei,HttpStatus.NOT_FOUND);
		
	}
	@org.springframework.web.bind.annotation.ExceptionHandler(value= {PlayerNotExistsException.class})
	public ResponseEntity<Object> handlePlayerNotExistsException(PlayerNotExistsException player) {
		ExceptionInfo ei=new ExceptionInfo(player.getMessage(),player.getCause(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ei,HttpStatus.NOT_FOUND);
		
	}
	@org.springframework.web.bind.annotation.ExceptionHandler(value= {PlayersLimitExceedsException.class})
	public ResponseEntity<Object> handlePlayerLimitExceedsException(PlayersLimitExceedsException player) {
		ExceptionInfo ei=new ExceptionInfo(player.getMessage(),player.getCause(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ei,HttpStatus.NOT_FOUND);
		
	}
	@org.springframework.web.bind.annotation.ExceptionHandler(value= {TeamBudgetExceedsException.class})
	public ResponseEntity<Object> handleTeamBudgetExceedsException(TeamBudgetExceedsException team) {
		ExceptionInfo ei=new ExceptionInfo(team.getMessage(),team.getCause(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ei,HttpStatus.NOT_FOUND);
		
	}
	

}
