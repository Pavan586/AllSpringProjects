package com.cricket.tournament.serviceimpl;

import java.util.ArrayList;

import java.util.List;

import jakarta.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cricket.tournament.entity.Login;
import com.cricket.tournament.entity.LoginMessage;
import com.cricket.tournament.entity.Players;
import com.cricket.tournament.entity.Teams;
import com.cricket.tournament.exception.IdNotFoundException;
import com.cricket.tournament.exception.PlayerAlreadyAssigned;
import com.cricket.tournament.exception.PlayerAlreadyExistsException;
import com.cricket.tournament.exception.PlayerNotExistsException;
import com.cricket.tournament.exception.PlayersLimitExceedsException;
import com.cricket.tournament.exception.TeamBudgetExceedsException;
import com.cricket.tournament.exception.TeamNotFoundException;
import com.cricket.tournament.repository.PlayersRepository;
import com.cricket.tournament.repository.TeamsRepository;
import com.cricket.tournament.service.PlayersService;

@Component
public class PlayersServiceImpl implements PlayersService {
	Integer sum=0;
	@Autowired
	private com.cricket.tournament.EmailSenderService senderService;
	@Autowired
	PlayersRepository cdr;
	@Autowired
	TeamsServiceImpl tsimpl;
	@Autowired
	TeamsRepository tr;
	public void triggerMail() throws MessagingException {
		senderService.sendSimpleEmail("pavanpulicherla315@gmail.com",
				"Assigned confirmation",
				"Congratulations,Your have been assigned to team successfully");

	}

	@Override
	public List<Players> getAllPlayers() {
		// TODO Auto-generated method stub
		return cdr.findAll();
	}

	@Override
	public Players updatePlayer(int playerId, Players players) {
		// TODO Auto-generated method stub
		Players ex=cdr.findById(playerId).get();
		ex.setPname(players.getPname());
		ex.setPemail(players.getPemail());
		ex.setPcategory(players.getPcategory());
		ex.setPcountry(players.getPcountry());
		ex.setPage(players.getPage());
		ex.setPbudget(players.getPbudget());
		cdr.save(ex);
		return ex;
	}

	@Override
	public void deletePlayer(int playerId) {
		// TODO Auto-generated method stub
		//cdr.deleteById(playerId);
		Players p=cdr.getById(playerId);
		p.setTeams(null);
		cdr.save(p);
		
		
	}

	@Override
	public void savePlayers(int teamId, Players players,List<Players> playersdata) {
		// TODO Auto-generated method stub
		int i,status=0;
		Teams teams=tsimpl.getTeamById(teamId);
		players.setTeams(teams);
		int count=cdr.getPlayersCount(teams.getTid());
		if(count<4) {		
			for(i=0;i<playersdata.size();i++) {
				System.out.println(playersdata.get(i));
				if(playersdata.get(i).getPname().equalsIgnoreCase(players.getPname())) {
					status=1;
					break;
				} 
			}
			if(status==0) {
				sum=cdr.getPlayersBudget(teams.getTid());
				if(sum==null) {
					sum=0;
				}
				int val=players.getPbudget();
				if(sum+val<=teams.getTbudget()) {
					cdr.save(players);
				} else {
					//LoginMessage msg=new LoginMessage("Team Budget Exceeds",false);
					throw new TeamBudgetExceedsException("Team Budget Exceeds");
				}
			} else {
				//LoginMessage msg=new LoginMessage("Player with this name is already Exists",false);
				throw new PlayerAlreadyExistsException("Player with this name is already Exists");
			}
		} else {
			//LoginMessage msg=new LoginMessage("Player Limit Exceeds",false);
			throw new PlayersLimitExceedsException("Player Limit Exceeds");
		}
		
		
	}

	@Override
	public List<Players> getPlayersByTeamName(String teamName) {
		// TODO Auto-generated method stub
		return cdr.findPlayersByTeamName(teamName);
	}

	@Override
	public Players getPlayerById(int playerId) {
		// TODO Auto-generated method stub
		Players p1= cdr.findById(playerId).orElseThrow(()->new PlayerNotExistsException("Player does not Exists"));
		return p1;

	}

	@Override
	public void savePlayersData(Players players,List<Players> playersinfo) {
		// TODO Auto-generated method stub
		int status=0;
		for(int i=0;i<playersinfo.size();i++) {
			if(playersinfo.get(i).getPname().equalsIgnoreCase(players.getPname())) {
				status=1;
				break;	
			}
		}
		if(status==0) {
		cdr.save(players);
		} else {
			throw new PlayerAlreadyExistsException("Player Already Exists");
		}
		
	}

	@Override
	public void assign(String tname,String pname,List<Players> playersdata) throws MessagingException {
		// TODO Auto-generated method stub
		int i,id;
		id=tr.findTeamIdByTeamName(tname);
		Teams teams=tsimpl.getTeamById(id);
		for(i=0;i<playersdata.size();i++) {
			if(playersdata.get(i).getPname().equalsIgnoreCase(pname)) {
				Players p=cdr.getById(playersdata.get(i).getPid());
				p.setTeams(teams);
				cdr.save(p);
				//triggerMail();
				senderService.sendSimpleEmail(playersdata.get(i).getPemail(),
						"Assigned confirmation",
						"Congratulations,Your have been assigned to team successfully");

				break;
			}

			}
	}

	@Override
	public List<Players> getAllUnsoldPlayers(List<Players> playersdata) {
		// TODO Auto-generated method stub
		List<Players> playersinfo=new ArrayList<Players>();
		for(int i=0;i<playersdata.size();i++) {
			if(playersdata.get(i).getTeams()==null) {
				playersinfo.add(playersdata.get(i));
				
			}
		}
		return playersinfo;
		
	}

	@Override
	public void deletePlayerFromAdmin(int playerId) {
		// TODO Auto-generated method stub
		Players p=cdr.getById(playerId);
		p.setTeams(null);
		cdr.deleteById(playerId);
		
	}
}
		