package com.cricket.tournament.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.cricket.tournament.entity.Players;
import com.cricket.tournament.entity.Teams;

public interface TeamsService {
	void saveTeams(Teams teams);
	Teams getTeamById(int tid);
	List<Teams> findTeamByName(String teamName);
	String findTeamByPlayerName(String playerName,List<Players> teamsdata);
	List<Teams> getAllTeams();
	

}
