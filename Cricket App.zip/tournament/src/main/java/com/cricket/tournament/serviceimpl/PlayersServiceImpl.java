package com.cricket.tournament.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cricket.tournament.entity.Players;
import com.cricket.tournament.entity.Teams;
import com.cricket.tournament.exception.PlayerAlreadyExistsException;
import com.cricket.tournament.repository.PlayersRepository;
import com.cricket.tournament.service.PlayersService;

@Component
public class PlayersServiceImpl implements PlayersService {
	@Autowired
	PlayersRepository cdr;
	@Autowired
	TeamsServiceImpl tsimpl;

	@Override
	public List<Players> getAllPlayers() {
		// TODO Auto-generated method stub
		return cdr.findAll();
	}

	@Override
	public Players updatePlayer(int playerId, Players players) {
		// TODO Auto-generated method stub
		Players ex=cdr.findById(playerId).get();
		ex.setPname(players.getPname());
		ex.setPcategory(players.getPcategory());
		ex.setPcountry(players.getPcountry());
		ex.setPage(players.getPage());
		cdr.save(ex);
		return ex;
	}

	@Override
	public void deletePlayer(int playerId) {
		// TODO Auto-generated method stub
		cdr.deleteById(playerId);
		
	}

	@Override
	public void savePlayers(int teamId, Players players,List<Players> playersdata) {
		// TODO Auto-generated method stub
		int i,status=0;
		Teams teams=tsimpl.getTeamById(teamId);
		players.setTeams(teams);
		for(i=0;i<playersdata.size();i++) {
			System.out.println(playersdata.get(i));
			if(playersdata.get(i).getPname().equalsIgnoreCase(players.getPname())) {
				status=1;
				break;
			} 
		}
		if(status==0) {
		cdr.save(players);
		} else {
			throw new PlayerAlreadyExistsException("Player with this name is already present in another team");
		}
		
	}

	@Override
	public List<String> getPlayersByTeamName(String teamName) {
		// TODO Auto-generated method stub
		return cdr.findPlayersByTeamName(teamName);
	}
	

}
