package com.cricket.tournament.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table
public class Teams {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int tid;
	private String tname;
	private int tbudget;
	@OneToMany(targetEntity=Players.class,cascade=CascadeType.ALL,mappedBy="teams")
	private List<Players> players;
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public int getTbudget() {
		return tbudget;
	}
	public void setTbudget(int tbudget) {
		this.tbudget = tbudget;
	}
	public List<Players> getPlayers() {
		return players;
	}
	public void setPlayers(List<Players> players) {
		this.players = players;
	}
	public Teams(int tid, String tname, int tbudget, List<Players> players) {
		super();
		this.tid = tid;
		this.tname = tname;
		this.tbudget = tbudget;
		this.players = players;
	}
	public Teams() {
		super();
	}
	@Override
	public String toString() {
		return "Teams [tid=" + tid + ", tname=" + tname + ", tbudget=" + tbudget + ", players=" + players + "]";
	}
}