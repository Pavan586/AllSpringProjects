package com.cricket.tournament.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cricket.tournament.entity.Players;

public interface PlayersService {
	void savePlayers(int teamId,Players players,List<Players> playersdata);
	List<Players> getAllPlayers();
	Players updatePlayer(int playerId,Players players);
	void deletePlayer(int playerId);
	List<String> getPlayersByTeamName(String teamName);
	


}
