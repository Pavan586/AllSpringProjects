package com.cricket.tournament.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cricket.tournament.entity.Players;
import com.cricket.tournament.entity.Teams;
import com.cricket.tournament.exception.IdNotFoundException;
import com.cricket.tournament.exception.PlayerNotExistsException;
import com.cricket.tournament.exception.TeamNotFoundException;
import com.cricket.tournament.serviceimpl.PlayersServiceImpl;
import com.cricket.tournament.serviceimpl.TeamsServiceImpl;

@RestController
@RequestMapping("/teams")
public class TeamsController {
	@Autowired
	TeamsServiceImpl tsimpl;
	@Autowired
	PlayersServiceImpl psimpl;
	@PostMapping("/addteams")
	public void saveTeams(@RequestBody Teams teams) {
		tsimpl.saveTeams(teams);
		
	}
	@GetMapping("/{tid}/getteambyid")
	public Object getTeamById(@PathVariable int tid) {
		try {
		return tsimpl.getTeamById(tid);
		} 
		catch(IdNotFoundException e) {
			return e.getMessage();
			
		}
		
	}
	@GetMapping("/{tname}/getteamdatabyteamname")
	public Object findTeamsByName(@PathVariable String tname) {
		try {
		return tsimpl.findTeamByName(tname);
		}
		catch(TeamNotFoundException e) {
			return e.getMessage();
			
		}
	}
	@GetMapping("/getallteams")
	public List<Teams> getAllTeams() {
		return tsimpl.getAllTeams();
	}
	@GetMapping("/{pname}/getteamnamebyplayername")
	public String getTeamnameByPlayerName(@PathVariable String pname) {
		List<Players> playersdata=psimpl.getAllPlayers();
		try {
		return tsimpl.findTeamByPlayerName(pname,playersdata);
		}
		catch(PlayerNotExistsException p) {
			return p.getMessage();
		}
		
		
	}

}
