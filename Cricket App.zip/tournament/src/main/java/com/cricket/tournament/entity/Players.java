package com.cricket.tournament.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Players {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int pid;
	private String pname;
	private String pcategory;
	private String pcountry;
	private int page;
	private int pbudget;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="team_id",referencedColumnName="tid")
	@JsonIgnore
	private Teams teams;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPcategory() {
		return pcategory;
	}
	public void setPcategory(String pcategory) {
		this.pcategory = pcategory;
	}
	public String getPcountry() {
		return pcountry;
	}
	public void setPcountry(String pcountry) {
		this.pcountry = pcountry;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	
	public Teams getTeams() {
		return teams;
	}
	public void setTeams(Teams teams) {
		this.teams = teams;
	}
	public int getPbudget() {
		return pbudget;
	}
	public void setPbudget(int pbudget) {
		this.pbudget = pbudget;
	}
	
	public Players(int pid, String pname, String pcategory, String pcountry, int page, int pbudget, Teams teams) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pcategory = pcategory;
		this.pcountry = pcountry;
		this.page = page;
		this.pbudget = pbudget;
		this.teams = teams;
	}
	public Players() {
		super();
	}
	@Override
	public String toString() {
		return "Players [pid=" + pid + ", pname=" + pname + ", pcategory=" + pcategory + ", pcountry=" + pcountry
				+ ", page=" + page + ", pbudget=" + pbudget + ", teams=" + teams + "]";
	}
	
}
	
	