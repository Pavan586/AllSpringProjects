package com.cricket.tournament.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class ExceptionHandler {
	@org.springframework.web.bind.annotation.ExceptionHandler(value= {TeamNotFoundException.class})
	public ResponseEntity<Object> handleTeamNotFoundException(TeamNotFoundException team) {
		ExceptionInfo ei=new ExceptionInfo(team.getMessage(),team.getCause(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ei,HttpStatus.NOT_FOUND);
		
	}
	@org.springframework.web.bind.annotation.ExceptionHandler(value= {IdNotFoundException.class})
	public ResponseEntity<Object> handleIdNotFoundException(IdNotFoundException id) {
		ExceptionInfo ei=new ExceptionInfo(id.getMessage(),id.getCause(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(ei,HttpStatus.NOT_FOUND);
		
	}
	
	

}
