package com.cricket.tournament.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cricket.tournament.entity.Players;
import com.cricket.tournament.serviceimpl.PlayersServiceImpl;

@RestController
@RequestMapping("/players")
public class PlayersController {
	@Autowired
	PlayersServiceImpl cdsimpl;
	@PostMapping("/{teamId}/addplayers")
	public void savePlayers(@PathVariable int teamId,@RequestBody Players players) {
		List<Players> playersdata=getPlayers();
		cdsimpl.savePlayers(teamId,players,playersdata);
	
	}
	@GetMapping("/getallplayers")
	public List<Players> getPlayers() {
		return cdsimpl.getAllPlayers();
		
	}
	@PutMapping("/{playerId}/updateplayer")
	public Players updatePlayer(@PathVariable int playerId,@RequestBody Players players) {
		return cdsimpl.updatePlayer(playerId,players);
	}
	@DeleteMapping("/{playerId}/deleteplayer")
	public void deletePlayer(@PathVariable int playerId) {
		cdsimpl.deletePlayer(playerId);
		
	}
	@GetMapping("/{teamName}/getplayersbyteamname")
	public List<String> getPlayersByTeamName(@PathVariable String teamName) {
		return cdsimpl.getPlayersByTeamName(teamName);
	}
}
