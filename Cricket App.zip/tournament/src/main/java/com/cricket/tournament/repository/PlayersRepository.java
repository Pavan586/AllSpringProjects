package com.cricket.tournament.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cricket.tournament.entity.Players;

public interface PlayersRepository extends JpaRepository<Players,Integer> {
	@Query("select p.pname from Players p where p.teams.tname=?1")
	public List<String> findPlayersByTeamName(String tname);
	

}
