package com.cricket.tournament.exception;

public class TeamNotFoundException extends RuntimeException {

	public TeamNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TeamNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
