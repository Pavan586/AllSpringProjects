package com.cricket.tournament.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cricket.tournament.entity.Players;
import com.cricket.tournament.entity.Teams;
import com.cricket.tournament.exception.IdNotFoundException;
import com.cricket.tournament.exception.PlayerNotExistsException;
import com.cricket.tournament.exception.TeamNotFoundException;
import com.cricket.tournament.repository.TeamsRepository;
import com.cricket.tournament.service.TeamsService;

@Component
public class TeamsServiceImpl implements TeamsService {
	@Autowired
	TeamsRepository tr;

	@Override
	public void saveTeams(Teams teams) {
		// TODO Auto-generated method
		tr.save(teams);
		
	}

	@Override
	public Teams getTeamById(int tid) {
		// TODO Auto-generated method stub
		Teams t1= tr.findById(tid).orElseThrow(()->new IdNotFoundException("Id does not Exists"));
		return t1;
		/*(if(t1==null) {
			throw new IdNotFoundException("Id does Not Exists");
		} else {
			return t1;
		}*/
	}

	@Override
	public List<Teams> findTeamByName(String teamName) {
		// TODO Auto-generated method stub
		List<Teams> team= tr.findTeamByTeamName(teamName);
		if(team.isEmpty()) {
			throw new TeamNotFoundException("Team does not exists");
		} else {
			return team;
		}
	}

	@Override
	public String findTeamByPlayerName(String playerName,List<Players> playersdata) {
		// TODO Auto-generated method stub
		int i,status=0;
		for(i=0;i<playersdata.size();i++) {
			System.out.println(playersdata.get(i));
			if(playersdata.get(i).getPname().equalsIgnoreCase(playerName)) {
				status=1;
				break;
			} else {
				status=0;
			}
			
		}
		if(status==1) {
			return playersdata.get(i).getTeams().getTname();

		} else {
			throw new PlayerNotExistsException("Player not exists");
		}
		
	}

	@Override
	public List<Teams> getAllTeams() {
		// TODO Auto-generated method stub
		return tr.findAll();
	}

}
