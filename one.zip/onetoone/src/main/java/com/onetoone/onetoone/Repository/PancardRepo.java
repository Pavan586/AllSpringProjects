package com.onetoone.onetoone.Repository;

public interface PancardRepo {

}
