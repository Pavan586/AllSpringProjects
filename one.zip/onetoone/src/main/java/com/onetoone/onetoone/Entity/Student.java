package com.onetoone.onetoone.Entity;

public class Student {

}
